package atv10;

public class Medico extends Pessoa {
	
	private String crm;
	
	public Medico() {
		
	}
	
	public Medico(String nome,String cpf,String endereco,String rg,String telefone,String crm) {
		super.setNome(nome);
		super.setCpf(cpf);
		super.setEndereco(endereco);
		super.setTelefone(telefone);
		super.setRg(rg);
		this.setCRM(crm);
	}
	
	public void setCRM(String crm) {
		this.crm = crm;
	}
	public String getCrm(String crm) {
		return this.crm;
	}
	public void Status() {
		System.out.println("Nome: " + super.getNome());
		System.out.println("Cpf: " + super.getCpf());
		System.out.println("Endereco: " + super.getEndereco());
		System.out.println("Rg: " + super.getRg());
		System.out.println("Telefone: " + super.getTelefone());
		System.out.println("Crm: " + this.crm);
	}
}
