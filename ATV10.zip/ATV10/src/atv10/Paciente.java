package atv10;

public class Paciente extends Pessoa {
	private Prontuario Ficha = new Prontuario();
	
	public Paciente() {
		
	}
	
	public Paciente(String nome,String cpf,String endereco,String rg,String telefone) {
		super.setNome(nome);
		super.setCpf(cpf);
		super.setEndereco(endereco);
		super.setTelefone(telefone);
		super.setRg(rg);
	}
	
}
