package atv10;

public abstract class Pessoa {
	private String nome;
	private String cpf;
	private String endereco;
	private String rg;
	private String telefone;

	
	public void Status() {
		System.out.println("Nome: " + this.nome);
		System.out.println("Cpf: " + this.cpf);
		System.out.println("Endereco: " + this.endereco);
		System.out.println("Rg: " + this.rg);
		System.out.println("Telefone: " + this.telefone);
	}
	public void setNome(String nome) {
		this.nome = nome;
	}
	
	public void setCpf(String cpf) {
		this.cpf = cpf;
	}
	
	public void setEndereco(String endereco) {
		this.endereco = endereco;
	}
	
	public void setRg(String rg) {
		this.rg = rg;
	}
	
	public void setTelefone(String telefone) {
		this.telefone = telefone;
	}
	
	public String getNome() {
		return this.nome;
	}
	
	public String getCpf() {
		return this.cpf;
	}
	
	public String getEndereco() {
		return this.endereco;
	}
	
	public String getRg() {
		return this.rg;
	}
	
	public String getTelefone() {
		return this.telefone;
	}
}
