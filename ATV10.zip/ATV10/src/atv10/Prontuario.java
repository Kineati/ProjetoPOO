package atv10;

public class Prontuario {
	private String Exame;
	private String Consulta;
	private String Medicamento;
	private Ocorrencia Info;
	private String Exames[];
	private String Consultas[];
	private String Medicamentos[];
	
	public Prontuario(){
            Info = new Ocorrencia();
	}
        public Prontuario(String Data,String Hora,String Convenio,String Medico,String Exame,String Consulta,String Medicamento){
            Info = new Ocorrencia(Data,Hora,Convenio,Medico);
            this.Exame = Exame;
            this.Consulta = Consulta;
            this.Medicamento = Medicamento;
        }
	public void setExame(String exame) {
		this.Exame = exame;
	}
	public void setConsulta(String consulta) {
		this.Consulta = consulta;
	}
	public void setMedicamento(String medicamento) {
		this.Medicamento = medicamento;
	}
        public void setData(String data){
            Info.setData(data);
        }
        public void setHora(String hora){
            Info.setHora(hora);
        }
        public void setConvenio(String Convenio){
            Info.setConvenio(Convenio);
        }
        public void setMedico(String Medico){
            Info.setMedico(Medico);
        }
	public String getExame() {
		return this.Exame;
	}
	public String getConsulta() {
		return this.Consulta;
	}
	public String getMedicamento() {
		return this.Medicamento;
	}
        public String getData(){
            return Info.getData();
        }
        public String getHora(){
            return Info.getHora();
        }
        public String getConvenio(){
            return Info.getConvenio();
        }
        public String getMedico(){
            return Info.getMedico();
        }
        
}
