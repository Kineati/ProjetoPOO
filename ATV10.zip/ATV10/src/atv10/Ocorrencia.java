package atv10;

public class Ocorrencia {
	private String data;
	private String hora;
	private String convenio;
	private String medico;
	public Ocorrencia(){
            
        }
        public Ocorrencia(String data,String Hora,String Convenio,String medico){
            this.data = data;
            this.hora = Hora;
            this.convenio = Convenio;
            this.medico = medico;
        }
	public void setData(String data) {
		this.data = data;
	}
	public void setHora(String exame) {
		this.hora = exame;
	}
	public void setConvenio(String exame) {
		this.convenio = exame;
	}
	public void setMedico(String exame) {
		this.medico = exame;
	}
	public String getData() {
		return this.data;
	}
	public String getHora() {
		return this.hora;
	}
	public String getConvenio() {
		return this.convenio;
	}
	public String getMedico() {
		return this.medico;
	}
}
